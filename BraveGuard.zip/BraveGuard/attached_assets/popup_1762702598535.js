// Elementos del DOM
const toggleBtn = document.getElementById("toggleBtn")
const statusBadge = document.getElementById("statusBadge")
const controlDesc = document.getElementById("controlDesc")
const blockedCountEl = document.getElementById("blockedCount")
const trackersCountEl = document.getElementById("trackersCount")
const sitesCountEl = document.getElementById("sitesCount")
const timeCountEl = document.getElementById("timeCount")

let isLoadingStats = false // Declare isLoadingStats variable

// Cargar datos al abrir popup
document.addEventListener("DOMContentLoaded", () => {
  loadStats()
  loadBlocklist()
  loadWhitelist()
  setupEventListeners()

  // Actualizar stats cada 2 segundos
  setInterval(loadStats, 2000)
})

// Cargar estadísticas
function loadStats() {
  if (isLoadingStats) return
  isLoadingStats = true

  window.chrome.runtime.sendMessage({ action: "getStats" }, (response) => {
    // Declare chrome variable
    isLoadingStats = false

    if (window.chrome.runtime.lastError) {
      console.error("[v0] Error:", window.chrome.runtime.lastError)
      return
    }

    if (!response) {
      console.log("[v0] No response from background")
      return
    }

    const stats = response.stats || {
      blocked: 0,
      trackers: 0,
      sites: 0,
      time: 0,
      daily: 0,
      weekly: 0,
      monthly: 0,
    }
    const isEnabled = response.isEnabled !== false

    blockedCountEl.textContent = stats.blocked
    trackersCountEl.textContent = stats.trackers
    sitesCountEl.textContent = stats.sites
    timeCountEl.textContent = formatTime(stats.time)
    document.getElementById("totalToday").textContent = stats.daily
    document.getElementById("totalWeek").textContent = stats.weekly
    document.getElementById("totalMonth").textContent = stats.monthly

    toggleBtn.checked = isEnabled
    updateStatus(isEnabled)
  })
}

// Cargar lista de bloqueados
function loadBlocklist() {
  window.chrome.runtime.sendMessage({ action: "getStats" }, (response) => {
    // Declare chrome variable
    if (window.chrome.runtime.lastError) {
      console.error("[v0] Error:", window.chrome.runtime.lastError)
      return
    }
    if (!response) return

    const blocked = Array.isArray(response.blocked) ? response.blocked : []
    const container = document.getElementById("blocklistItems")

    if (blocked.length === 0) {
      container.innerHTML = '<div class="empty-state">No hay anuncios bloqueados en esta sesión</div>'
      return
    }

    container.innerHTML = blocked
      .slice(-15)
      .reverse()
      .map((item, i) => {
        const url = typeof item === "string" ? item : item.url
        const displayUrl = url.length > 50 ? url.substring(0, 47) + "..." : url
        const escapedUrl = escapeHTML(url)
        const actualIndex = blocked.length - 1 - i
        return `
      <div class="list-item">
        <span class="list-item-url" title="${escapedUrl}">${escapeHTML(displayUrl)}</span>
        <button class="remove-btn" data-index="${actualIndex}">✕</button>
      </div>
    `
      })
      .join("")

    container.querySelectorAll(".remove-btn").forEach((btn) => {
      btn.addEventListener("click", () => {
        const index = Number.parseInt(btn.dataset.index)
        removeBlocked(index)
      })
    })
  })
}

function escapeHTML(str) {
  const div = document.createElement("div")
  div.textContent = str
  return div.innerHTML
}

// Cargar whitelist
function loadWhitelist() {
  window.chrome.storage.local.get(["whitelist"], (result) => {
    // Declare chrome variable
    if (window.chrome.runtime.lastError) {
      console.error("[v0] Error:", window.chrome.runtime.lastError)
      return
    }
    const whitelist = result.whitelist || []
    const container = document.getElementById("whitelistItems")

    if (whitelist.length === 0) {
      container.innerHTML = '<div class="empty-state">No hay sitios en whitelist</div>'
      return
    }

    container.innerHTML = whitelist
      .map(
        (site, i) => `
      <div class="list-item">
        <span class="list-item-url">${escapeHTML(site)}</span>
        <button class="remove-btn" data-index="${i}">✕</button>
      </div>
    `,
      )
      .join("")

    container.querySelectorAll(".remove-btn").forEach((btn) => {
      btn.addEventListener("click", () => {
        const index = Number.parseInt(btn.dataset.index)
        removeWhitelist(index)
      })
    })
  })
}

// Configurar event listeners
function setupEventListeners() {
  // Toggle de protección
  toggleBtn.addEventListener("change", (e) => {
    const isEnabled = e.target.checked
    console.log("[v0] Toggling protection to:", isEnabled)
    window.chrome.runtime.sendMessage({ action: "toggle", enabled: isEnabled }, (response) => {
      // Declare chrome variable
      if (window.chrome.runtime.lastError) {
        console.error("[v0] Error:", window.chrome.runtime.lastError)
        return
      }
      if (response && response.success) {
        updateStatus(isEnabled)
        console.log("[v0] Protection toggled successfully")
      } else {
        console.log("[v0] Error toggling protection")
      }
    })
  })

  // Tabs - Corregir el manejo de tabs para que funcionen correctamente
  document.querySelectorAll(".tab-btn").forEach((btn) => {
    btn.addEventListener("click", (e) => {
      const tabName = e.currentTarget.dataset.tab
      switchTab(tabName, e.currentTarget)
    })
  })

  // Agregar a whitelist
  document.getElementById("addWhitelistBtn").addEventListener("click", addCurrentSiteToWhitelist)

  // Reiniciar estadísticas
  document.getElementById("resetBtn").addEventListener("click", () => {
    if (confirm("¿Reiniciar todas las estadísticas?")) {
      window.chrome.runtime.sendMessage({ action: "resetStats" }, () => {
        // Declare chrome variable
        if (window.chrome.runtime.lastError) {
          console.error("[v0] Error:", window.chrome.runtime.lastError)
          return
        }
        loadStats()
        loadBlocklist()
      })
    }
  })
}

// Actualizar estado
function updateStatus(isEnabled) {
  statusBadge.textContent = isEnabled ? "Activo" : "Inactivo"
  statusBadge.classList.toggle("inactive", !isEnabled)
  controlDesc.textContent = isEnabled ? "Protección activa en esta página" : "Protección desactivada"
}

function switchTab(tabName, clickedElement) {
  document.querySelectorAll(".tab-content").forEach((tab) => {
    tab.classList.remove("active")
  })
  document.querySelectorAll(".tab-btn").forEach((btn) => {
    btn.classList.remove("active")
  })

  document.getElementById(tabName).classList.add("active")
  clickedElement.classList.add("active")

  if (tabName === "blocklist") loadBlocklist()
  if (tabName === "whitelist") loadWhitelist()
}

// Formatear tiempo
function formatTime(seconds) {
  if (seconds < 60) return `${Math.round(seconds)}s`
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m`
  return `${(seconds / 3600).toFixed(1)}h`
}

function removeBlocked(index) {
  window.chrome.storage.local.get(["blocked"], (result) => {
    // Declare chrome variable
    if (window.chrome.runtime.lastError) {
      console.error("[v0] Error:", window.chrome.runtime.lastError)
      return
    }
    const blocked = result.blocked || []
    if (index >= 0 && index < blocked.length) {
      blocked.splice(index, 1)
      window.chrome.storage.local.set({ blocked }, () => {
        // Declare chrome variable
        if (window.chrome.runtime.lastError) {
          console.error("[v0] Error:", window.chrome.runtime.lastError)
          return
        }
        loadBlocklist()
      })
    }
  })
}

// Agregar sitio a whitelist
function addCurrentSiteToWhitelist() {
  window.chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    // Declare chrome variable
    if (window.chrome.runtime.lastError) {
      console.error("[v0] Error:", window.chrome.runtime.lastError)
      return
    }
    if (!tabs[0] || !tabs[0].url) {
      alert("❌ No se pudo obtener la URL de la pestaña actual")
      return
    }

    try {
      const url = new URL(tabs[0].url)
      const hostname = url.hostname

      if (url.protocol === "chrome:" || url.protocol === "chrome-extension:") {
        alert("❌ No se pueden agregar páginas especiales a la whitelist")
        return
      }

      window.chrome.storage.local.get(["whitelist"], (result) => {
        // Declare chrome variable
        if (window.chrome.runtime.lastError) {
          console.error("[v0] Error:", window.chrome.runtime.lastError)
          return
        }
        const whitelist = result.whitelist || []
        if (!whitelist.includes(hostname)) {
          whitelist.push(hostname)
          window.chrome.storage.local.set({ whitelist }, () => {
            // Declare chrome variable
            if (window.chrome.runtime.lastError) {
              console.error("[v0] Error:", window.chrome.runtime.lastError)
              return
            }
            loadWhitelist()
            alert(`✅ ${hostname} agregado a whitelist`)
          })
        } else {
          alert(`ℹ️ ${hostname} ya está en whitelist`)
        }
      })
    } catch (e) {
      console.log("[v0] Error processing URL:", e)
      alert("❌ Error al procesar URL")
    }
  })
}

// Remover de whitelist
function removeWhitelist(index) {
  window.chrome.storage.local.get(["whitelist"], (result) => {
    // Declare chrome variable
    if (window.chrome.runtime.lastError) {
      console.error("[v0] Error:", window.chrome.runtime.lastError)
      return
    }
    const whitelist = result.whitelist || []
    if (index >= 0 && index < whitelist.length) {
      whitelist.splice(index, 1)
      window.chrome.storage.local.set({ whitelist }, () => {
        // Declare chrome variable
        if (window.chrome.runtime.lastError) {
          console.error("[v0] Error:", window.chrome.runtime.lastError)
          return
        }
        loadWhitelist()
      })
    }
  })
}
