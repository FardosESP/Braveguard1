;(() => {
  console.log("[v0] Injected ad-blocking script initializing...")

  // Prevenir Google AdSense
  window.adsbygoogle = window.adsbygoogle || []
  window.adsbygoogle.push = () => {
    console.log("[v0] Blocked adsbygoogle.push()")
    return
  }

  // Prevenir Google Analytics
  window.ga = () => {
    console.log("[v0] Blocked ga()")
    return
  }
  window.gtag = () => {
    console.log("[v0] Blocked gtag()")
    return
  }

  // Prevenir Facebook pixel
  window.fbq = () => {
    console.log("[v0] Blocked fbq()")
    return
  }

  window._gaq = []
  window.dataLayer = window.dataLayer || []

  // Bloquear Segment
  window.analytics = {
    track: () => console.log("[v0] Blocked Segment track()"),
    page: () => console.log("[v0] Blocked Segment page()"),
    identify: () => console.log("[v0] Blocked Segment identify()"),
  }

  const blockedDomains = [
    "doubleclick",
    "pagead",
    "googleads",
    "adsbygoogle",
    "facebook.com/tr",
    "analytics.google",
    "google-analytics",
    "segment.com",
    "mixpanel.com",
    "taboola.com",
    "outbrain.com",
    "amazon-adsystem.com",
    "googlesyndication.com",
    "googleadservices.com",
  ]

  function isBlockedUrl(url) {
    if (!url) return false
    const urlString = typeof url === "string" ? url : url.toString()
    return blockedDomains.some((domain) => urlString.toLowerCase().includes(domain))
  }

  const originalFetch = window.fetch
  window.fetch = function (...args) {
    const url = args[0]
    if (typeof url === "string" || url instanceof URL || url instanceof Request) {
      const urlToCheck = url instanceof Request ? url.url : url
      if (isBlockedUrl(urlToCheck)) {
        console.log("[v0] Blocked fetch to:", urlToCheck)
        return Promise.reject(new Error("Blocked by AdBlock Pro"))
      }
    }
    return originalFetch.apply(this, args)
  }

  const originalOpen = XMLHttpRequest.prototype.open
  XMLHttpRequest.prototype.open = function (method, url, ...rest) {
    if (isBlockedUrl(url)) {
      console.log("[v0] Blocked XMLHttpRequest to:", url)
      // Crear una petición que falla silenciosamente
      this.addEventListener("readystatechange", function () {
        if (this.readyState === 4) {
          Object.defineProperty(this, "status", { value: 0 })
          Object.defineProperty(this, "responseText", { value: "" })
        }
      })
      return
    }
    return originalOpen.apply(this, [method, url, ...rest])
  }

  const originalWindowOpen = window.open
  window.open = function (url, ...args) {
    if (url && isBlockedUrl(url)) {
      console.log("[v0] Blocked popup to:", url)
      return null
    }
    // Bloquear popups sin interacción del usuario
    if (!args[0] && url) {
      console.log("[v0] Blocked suspicious popup")
      return null
    }
    return originalWindowOpen.apply(this, [url, ...args])
  }

  console.log("[v0] Ad-blocking script loaded successfully")
})()
