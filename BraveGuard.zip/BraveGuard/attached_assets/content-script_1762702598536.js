// Rastreador de bloqueos para comunicar al background
const blockTracker = {
  ads: 0,
  trackers: 0,
}

let observerTimeout = null
const OBSERVER_DELAY = 1000 // ms

let domObserver = null

// Esperar a que el DOM esté listo
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", init)
} else {
  init()
}

function init() {
  console.log("[v0] Content script initializing...")
  window.chrome.storage.local.get(["isEnabled", "whitelist"], (result) => {
    if (window.chrome.runtime.lastError) {
      console.error("[v0] Error:", window.chrome.runtime.lastError)
      return
    }

    const isEnabled = result.isEnabled !== false
    console.log("[v0] Extension enabled:", isEnabled)

    if (isEnabled) {
      // Verificar whitelist
      const whitelist = result.whitelist || []
      const hostname = window.location.hostname
      const isWhitelisted = whitelist.some((domain) => hostname.includes(domain))

      if (isWhitelisted) {
        console.log("[v0] Site is whitelisted:", hostname)
        return
      }

      // Iniciar bloqueo
      blockAds()
      blockTrackers()
      observeDOMChanges()
      injectScript()
      console.log("[v0] Ad blocking active")
    } else {
      console.log("[v0] Ad blocking disabled")
    }
  })
}

function injectScript() {
  try {
    const script = document.createElement("script")
    script.src = window.chrome.runtime.getURL("injected-script.js")
    script.onload = () => script.remove()
    ;(document.head || document.documentElement).appendChild(script)
  } catch (e) {
    console.error("[v0] Error injecting script:", e)
  }
}

// Bloquear anuncios existentes
function blockAds() {
  console.log("[v0] Blocking ads...")
  let blockedCount = 0

  // Eliminar scripts de anuncios
  const scripts = document.querySelectorAll("script")
  scripts.forEach((script) => {
    if (!script.src) return

    const src = script.src.toLowerCase()

    const isAd =
      src.includes("doubleclick") ||
      src.includes("pagead") ||
      src.includes("googleads") ||
      src.includes("adsbygoogle") ||
      src.includes("amazon-adsystem") ||
      src.includes("taboola") ||
      src.includes("outbrain") ||
      src.includes("/ads/") ||
      src.includes("/ad.js") ||
      src.includes("/ads.js")

    if (isAd) {
      script.remove()
      notifyBlock(script.src, "ad")
      blockedCount++
    }
  })

  // Eliminar iframes de anuncios
  const iframes = document.querySelectorAll("iframe")
  iframes.forEach((iframe) => {
    const src = (iframe.src || "").toLowerCase()
    const id = (iframe.id || "").toLowerCase()
    const className = (iframe.className || "").toLowerCase()

    const isAd =
      src.includes("doubleclick") ||
      src.includes("pagead") ||
      src.includes("googleads") ||
      src.includes("/ads/") ||
      id.includes("ad") ||
      id.includes("google_ads") ||
      className.includes("ad")

    if (isAd) {
      iframe.remove()
      notifyBlock(iframe.src || "iframe-ad", "ad")
      blockedCount++
    }
  })

  const adSelectors = `
    [class*='ad-'], [class*='-ad-'], [class*='_ad_'],
    [id*='ad-'], [id*='-ad-'], [id*='_ad_'],
    [class*='banner'], [id*='banner'],
    [class*='advert'], [id*='advert'],
    .advertisement, .advert, .ads,
    .ad-container, .ad-slot, .ad-unit,
    [data-ad-slot], [data-advertisement],
    ins.adsbygoogle
  `

  try {
    const elements = document.querySelectorAll(adSelectors)
    elements.forEach((el) => {
      // Solo ocultar elementos visibles y con tamaño razonable
      if (el && el.offsetHeight > 10 && el.offsetWidth > 10) {
        el.style.display = "none"
        el.style.visibility = "hidden"
        el.style.opacity = "0"
        blockedCount++
      }
    })
  } catch (e) {
    console.error("[v0] Error blocking ads:", e)
  }

  if (blockedCount > 0) {
    console.log("[v0] Blocked", blockedCount, "ad elements")
  }
}

// Bloquear rastreadores
function blockTrackers() {
  console.log("[v0] Blocking trackers...")

  const scripts = document.querySelectorAll("script")
  scripts.forEach((script) => {
    const src = script.src.toLowerCase()

    const isTracker =
      src.includes("google-analytics") ||
      src.includes("analytics.google") ||
      src.includes("gtag") ||
      src.includes("facebook.com/tr") ||
      src.includes("segment.com") ||
      src.includes("mixpanel") ||
      src.includes("amplitude") ||
      src.includes("tracking")

    if (isTracker) {
      script.remove()
      notifyBlock(script.src, "tracker")
      blockTracker.trackers++
    }
  })

  // Bloquear pixels de rastreo
  const images = document.querySelectorAll("img")
  images.forEach((img) => {
    const src = (img.src || "").toLowerCase()
    const isTracker = src.includes("facebook") || src.includes("track")

    if (isTracker && (src.includes("1x1") || img.width === 1 || img.height === 1)) {
      img.style.display = "none"
      blockTracker.trackers++
    }
  })
}

function observeDOMChanges() {
  if (domObserver) {
    domObserver.disconnect()
  }

  domObserver = new MutationObserver((mutations) => {
    // Cancelar timeout anterior
    if (observerTimeout) {
      clearTimeout(observerTimeout)
    }

    // Programar nueva verificación con throttling
    observerTimeout = setTimeout(() => {
      let hasNewAds = false

      for (const mutation of mutations) {
        if (mutation.type === "childList") {
          mutation.addedNodes.forEach((node) => {
            if (node.nodeType === Node.ELEMENT_NODE) {
              // Verificar scripts
              if (node.tagName === "SCRIPT" && node.src && isAdScript(node.src)) {
                node.remove()
                notifyBlock(node.src, "ad")
                hasNewAds = true
              }
              // Verificar iframes
              else if (node.tagName === "IFRAME" && node.src && isAdScript(node.src)) {
                node.remove()
                notifyBlock(node.src, "ad")
                hasNewAds = true
              }
              // Verificar elementos con clases de anuncios
              else if (node.classList) {
                const hasAdClass = Array.from(node.classList).some((cls) => cls.toLowerCase().includes("ad"))
                if (hasAdClass && node.offsetHeight > 10) {
                  node.style.display = "none"
                  hasNewAds = true
                }
              }
            }
          })
        }
      }

      if (hasNewAds) {
        blockAds()
      }
    }, OBSERVER_DELAY)
  })

  domObserver.observe(document.documentElement, {
    childList: true,
    subtree: true,
  })

  console.log("[v0] DOM observer active")
}

// Verificar si es script de anuncios
function isAdScript(url) {
  const lower = url.toLowerCase()
  return (
    lower.includes("doubleclick") ||
    lower.includes("pagead") ||
    lower.includes("googleads") ||
    lower.includes("amazon-adsystem") ||
    lower.includes("taboola") ||
    lower.includes("outbrain")
  )
}

// Notificar al background
function notifyBlock(url, type) {
  window.chrome.runtime.sendMessage(
    {
      action: "blockAd",
      url: url,
      type: type,
    },
    (response) => {
      if (window.chrome.runtime.lastError) {
        console.error("[v0] Error sending message:", window.chrome.runtime.lastError.message)
        return
      }
      if (response && response.success) {
        console.log("[v0] Notified background of block:", url)
      }
    },
  )
}

// Escuchar cambios de estado
window.chrome.storage.onChanged.addListener((changes) => {
  if (changes.isEnabled) {
    console.log("[v0] Extension toggled, reloading page")
    if (domObserver) {
      domObserver.disconnect()
    }
    location.reload()
  }
})
