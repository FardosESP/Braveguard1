// Patrones de anuncios y rastreadores
const AD_PATTERNS = [/ads?\//i, /advert/i, /banner/i, /pagead/i, /doubleclick/i]

const TRACKER_PATTERNS = [
  /analytics/i,
  /google-analytics/i,
  /gtag/i,
  /tracking/i,
  /facebook.*pixel/i,
  /segment/i,
  /mixpanel/i,
]

const blockedSites = new Set()

// Declare chrome variable
const chrome = window.chrome

// Inicializar storage en la primera instalación
chrome.runtime.onInstalled.addListener(() => {
  console.log("[v0] AdBlock Pro installed")
  const now = new Date()
  chrome.storage.local.set({
    stats: {
      blocked: 0,
      trackers: 0,
      sites: 0,
      daily: 0,
      weekly: 0,
      monthly: 0,
    },
    isEnabled: true,
    blocked: [],
    whitelist: [],
    lastReset: {
      day: now.toDateString(),
      week: getWeekNumber(now),
      month: now.getMonth(),
      year: now.getFullYear(),
    },
  })
})

function getWeekNumber(date) {
  const firstDayOfYear = new Date(date.getFullYear(), 0, 1)
  const pastDaysOfYear = (date - firstDayOfYear) / 86400000
  return Math.ceil((pastDaysOfYear + firstDayOfYear.getDay() + 1) / 7)
}

function checkAndResetStats() {
  chrome.storage.local.get(["stats", "lastReset"], (result) => {
    if (!result.lastReset) return

    const now = new Date()
    const stats = result.stats || {}
    const lastReset = result.lastReset
    let needsUpdate = false

    // Reset diario
    if (lastReset.day !== now.toDateString()) {
      stats.daily = 0
      lastReset.day = now.toDateString()
      needsUpdate = true
    }

    // Reset semanal
    const currentWeek = getWeekNumber(now)
    if (lastReset.week !== currentWeek) {
      stats.weekly = 0
      lastReset.week = currentWeek
      needsUpdate = true
    }

    // Reset mensual
    if (lastReset.month !== now.getMonth() || lastReset.year !== now.getFullYear()) {
      stats.monthly = 0
      lastReset.month = now.getMonth()
      lastReset.year = now.getFullYear()
      needsUpdate = true
    }

    if (needsUpdate) {
      chrome.storage.local.set({ stats, lastReset })
    }
  })
}

// Verificar stats cada hora
setInterval(checkAndResetStats, 3600000)
checkAndResetStats() // Verificar al iniciar

// Escuchar mensajes del popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log("[v0] Message received:", request.action)

  if (request.action === "getStats") {
    checkAndResetStats() // Verificar antes de enviar stats
    chrome.storage.local.get(["stats", "blocked", "isEnabled"], (result) => {
      sendResponse({
        stats: result.stats || {
          blocked: 0,
          trackers: 0,
          sites: 0,
          daily: 0,
          weekly: 0,
          monthly: 0,
        },
        blocked: result.blocked || [],
        isEnabled: result.isEnabled !== false,
      })
    })
    return true
  }

  if (request.action === "blockAd") {
    logBlocked(request.url, request.type)
    sendResponse({ success: true })
    return true
  }

  if (request.action === "toggle") {
    const isEnabled = request.enabled
    console.log("[v0] Toggling to:", isEnabled)

    chrome.storage.local.set({ isEnabled }, () => {
      // Actualizar las reglas de bloqueo
      chrome.declarativeNetRequest
        .updateEnabledRulesets({
          enableRulesetIds: isEnabled ? ["ruleset_main"] : [],
          disableRulesetIds: isEnabled ? [] : ["ruleset_main"],
        })
        .then(() => {
          console.log("[v0] Rulesets updated, enabled:", isEnabled)
          // Actualizar badge
          if (!isEnabled) {
            chrome.action.setBadgeText({ text: "" })
          }
          sendResponse({ success: true })
        })
        .catch((error) => {
          console.error("[v0] Error updating rulesets:", error)
          sendResponse({ success: false, error: error.message })
        })
    })
    return true
  }

  if (request.action === "resetStats") {
    const now = new Date()
    chrome.storage.local.set({
      stats: {
        blocked: 0,
        trackers: 0,
        sites: 0,
        daily: 0,
        weekly: 0,
        monthly: 0,
      },
      blocked: [],
      lastReset: {
        day: now.toDateString(),
        week: getWeekNumber(now),
        month: now.getMonth(),
        year: now.getFullYear(),
      },
    })
    sendResponse({ success: true })
    return true
  }

  sendResponse({ success: false })
  return true
})

// Registrar bloqueados
function logBlocked(url, type = "ad") {
  chrome.storage.local.get(["stats", "blocked", "whitelist", "isEnabled"], (result) => {
    const isEnabled = result.isEnabled !== false
    if (!isEnabled) {
      console.log("[v0] Blocking disabled, not logging")
      return
    }

    const whitelist = result.whitelist || []
    const stats = result.stats || {
      blocked: 0,
      trackers: 0,
      sites: 0,
      daily: 0,
      weekly: 0,
      monthly: 0,
    }
    let blocked = result.blocked || []

    try {
      const urlObj = new URL(url)
      const isWhitelisted = whitelist.some((domain) => urlObj.hostname.includes(domain))
      if (isWhitelisted) {
        console.log("[v0] URL in whitelist, not blocking:", url)
        return
      }

      const domain = urlObj.hostname
      if (!blockedSites.has(domain)) {
        blockedSites.add(domain)
        stats.sites++
      }
    } catch (e) {
      console.log("[v0] Error parsing URL:", url, e)
    }

    // Categorizar usando los patrones definidos
    const isTrackerUrl = isTracker(url)
    const isAdUrl = isAd(url)

    if (type === "tracker" || isTrackerUrl) {
      stats.trackers++
    }

    if (type === "ad" || isAdUrl) {
      stats.blocked++
      stats.daily++
      stats.weekly++
      stats.monthly++
    }

    blocked.push({ url, timestamp: Date.now(), type })

    if (blocked.length > 100) blocked = blocked.slice(-100)

    chrome.storage.local.set({ stats, blocked })
    console.log("[v0] Blocked:", url, "Type:", type)

    updateBadge()
  })
}

function isTracker(url) {
  return TRACKER_PATTERNS.some((pattern) => pattern.test(url))
}

function isAd(url) {
  return AD_PATTERNS.some((pattern) => pattern.test(url))
}

// Escuchar cambios de tabs para actualizar badge
chrome.tabs.onActivated.addListener((activeInfo) => {
  updateBadge(activeInfo.tabId)
})

function updateBadge(tabId) {
  chrome.storage.local.get(["stats", "isEnabled"], (result) => {
    const stats = result.stats || { blocked: 0 }
    const isEnabled = result.isEnabled !== false

    if (isEnabled && stats.blocked > 0) {
      const options = { text: stats.blocked.toString() }
      if (tabId) options.tabId = tabId
      chrome.action.setBadgeText(options)
      chrome.action.setBadgeBackgroundColor({ color: "#22c55e" })
    } else {
      const options = { text: "" }
      if (tabId) options.tabId = tabId
      chrome.action.setBadgeText(options)
    }
  })
}
