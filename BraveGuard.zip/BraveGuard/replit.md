# AdBlock Pro - Extensión de Navegador

## Descripción del Proyecto

Este proyecto contiene una **extensión completa de navegador** para Brave/Chrome que proporciona protección total contra:
- Anuncios (Google Ads, Facebook, Amazon, etc.)
- Rastreadores (Analytics, Pixels, etc.)
- Minería de criptomonedas (Coinhive, CryptoLoot, etc.)
- Preparado para detectar sitios fraudulentos

## Estructura

- `extension/` - Todos los archivos de la extensión (listos para cargar en Brave)
- `docs/` - Página de documentación HTML con instrucciones de instalación
- `server.js` - Servidor HTTP que sirve la documentación

## Cómo Funciona en Replit

Este Repl sirve una **página de documentación** que explica cómo instalar la extensión en Brave/Chrome. La extensión en sí NO corre en Replit - debe instalarse en el navegador.

### Para Usar la Extensión:

1. Ve al webview de este Repl para ver las instrucciones completas
2. Descarga la carpeta `extension/` a tu computadora
3. Abre `brave://extensions/` en Brave
4. Activa "Modo de desarrollador"
5. Carga la carpeta `extension/` como extensión sin empaquetar

## Estado Actual

✅ Extensión completa y funcional
✅ 60+ reglas de bloqueo implementadas
✅ Detección de minería de criptomonedas
✅ UI moderna con estadísticas en tiempo real
✅ Sistema de whitelist
✅ Documentación completa

## Próximos Pasos

- Integración con APIs de detección de phishing
- Detección avanzada de CPU para miners
- Actualización automática de reglas
- Sincronización entre dispositivos

## Cambios Recientes

- 2024-11-09: Proyecto inicial creado con extensión completa
- Implementado Manifest V3 con Declarative Net Request API
- Agregadas 60 reglas de bloqueo
- Sistema de detección de minería implementado
- Página de documentación creada
- Agregado botón de descarga directa (TAR.GZ) en la página de documentación
- Corregido bug crítico de mensajería asíncrona en background.js toggle handler
