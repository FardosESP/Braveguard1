# AdBlock Pro - Protección Total para Navegadores

Extensión avanzada para Brave y Chrome que bloquea **anuncios**, **rastreadores**, **scripts de minería de criptomonedas** y **sitios fraudulentos**.

## 🚀 Características

- ✅ **Bloqueador de Anuncios**: 60+ reglas para bloquear anuncios de Google, Facebook, Amazon, Taboola, y más
- ✅ **Anti-Rastreadores**: Bloquea Google Analytics, Facebook Pixel, Mixpanel, Segment, etc.
- ✅ **Anti-Minería**: Detecta y bloquea scripts de minería de criptomonedas (Coinhive, CryptoLoot, JSEcoin)
- ✅ **Protección contra Fraude**: Sistema preparado para detectar sitios fraudulentos
- ✅ **Estadísticas Detalladas**: Contador en tiempo real de amenazas bloqueadas
- ✅ **Ultra Ligero**: 100% JavaScript vanilla, sin dependencias externas

## 📦 Estructura del Proyecto

```
├── extension/              # Archivos de la extensión del navegador
│   ├── manifest.json      # Configuración de la extensión (Manifest V3)
│   ├── background.js      # Service Worker (gestión de bloqueos y estadísticas)
│   ├── content-script.js  # Script de contenido (bloqueo DOM)
│   ├── injected-script.js # Script inyectado (bloqueo nivel página)
│   ├── popup.html         # UI del popup
│   ├── popup.js           # Lógica del popup
│   ├── rules.json         # Reglas declarativas de bloqueo
│   └── icon*.png          # Iconos de la extensión
├── docs/                   # Documentación web
│   ├── index.html         # Página de documentación
│   └── styles.css         # Estilos de la documentación
└── server.js              # Servidor HTTP para documentación
```

## 🔧 Instalación en Brave/Chrome

### Opción 1: Desde este Repl

1. Visita la **página de documentación** en el webview de este Repl
2. Sigue las instrucciones detalladas de instalación

### Opción 2: Manual

1. Descarga todos los archivos de la carpeta `extension/`
2. Abre `brave://extensions/` en tu navegador
3. Activa el **Modo de desarrollador**
4. Haz clic en **"Cargar extensión sin empaquetar"**
5. Selecciona la carpeta `extension/`
6. ¡Listo! La extensión estará activa

## 🎮 Cómo Usar

- **Ver Estadísticas**: Haz clic en el icono 🛡️ en la barra de extensiones
- **Agregar a Whitelist**: Desde el popup, pestaña "Whitelist"
- **Desactivar Temporalmente**: Usa el interruptor en el popup
- **Ver Bloqueados**: Pestaña "Bloqueados" muestra las URLs bloqueadas en tiempo real

## 🛡️ ¿Qué Bloquea?

### Anuncios
- Google Ads (DoubleClick, AdSense)
- Amazon Advertising
- Facebook Ads
- Taboola, Outbrain, Criteo
- Media.net, RevContent, MGID
- Y 50+ redes publicitarias más

### Rastreadores
- Google Analytics
- Facebook Pixel
- Mixpanel, Segment, Amplitude
- Hotjar, CrazyEgg, Mouseflow
- Chartbeat, Quantcast

### Minería de Criptomonedas
- Coinhive
- CryptoLoot
- JSEcoin
- WebMinePool
- Deepminer
- AuthedMine
- Y otros miners conocidos

## ⚙️ Especificaciones Técnicas

- **Manifest Version**: 3 (compatible con Chromium moderno)
- **Permisos**: storage, tabs, declarativeNetRequest, scripting, webNavigation
- **Reglas de Bloqueo**: 60 dominios bloqueados vía Declarative Net Request
- **Compatibilidad**: Brave, Chrome, Edge (navegadores basados en Chromium)

## 🔮 Próximas Funcionalidades

- [ ] Integración con APIs de detección de phishing (Google Safe Browsing, PhishTank)
- [ ] Detección avanzada de minería usando análisis de CPU
- [ ] Actualización automática de listas de bloqueo desde repositorios
- [ ] Sincronización de configuraciones entre dispositivos
- [ ] Exportar/importar configuraciones

## 📝 Desarrollo

### Servidor de Documentación

Este proyecto incluye un servidor HTTP simple para servir la página de documentación:

```bash
node server.js
```

El servidor corre en `http://localhost:5000` y sirve:
- Documentación HTML en `/`
- Archivos de la extensión en `/extension/`

### Modificar Reglas de Bloqueo

Edita `extension/rules.json` para agregar nuevas reglas de bloqueo. Usa el formato de Declarative Net Request API.

## 🤝 Contribuciones

Este proyecto está en desarrollo activo. Algunas mejoras sugeridas:

1. **Más Reglas**: Agregar dominios adicionales a `rules.json`
2. **Mejores Iconos**: Diseñar iconos profesionales para la extensión
3. **Detección de Fraude**: Implementar lista de sitios fraudulentos conocidos
4. **Tests**: Agregar pruebas automatizadas

## 📄 Licencia

Este proyecto es de código abierto y está disponible para uso personal y educativo.

## 🛠️ Problemas Comunes

**P: La extensión no bloquea anuncios en YouTube**  
R: YouTube usa técnicas avanzadas de anti-bloqueo. Considera usar extensiones especializadas.

**P: Un sitio no funciona correctamente**  
R: Agrégalo a la whitelist desde el popup de la extensión.

**P: ¿Cómo actualizo la extensión?**  
R: Descarga los archivos actualizados y vuelve a cargar la extensión en `brave://extensions/`.

---

**Hecho con 🛡️ para proteger tu privacidad**
