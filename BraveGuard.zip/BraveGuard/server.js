const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = 5000;

const server = http.createServer((req, res) => {
  console.log(`Request: ${req.method} ${req.url}`);

  if (req.url === '/download-extension') {
    const archivePath = path.join(__dirname, 'extension.tar.gz');
    
    fs.stat(archivePath, (err, stats) => {
      if (err) {
        res.writeHead(404, { 'Content-Type': 'text/html' });
        res.end('<h1>404 - Archive not found</h1>', 'utf-8');
        return;
      }

      res.writeHead(200, {
        'Content-Type': 'application/gzip',
        'Content-Disposition': 'attachment; filename="adblock-pro-extension.tar.gz"',
        'Content-Length': stats.size,
        'Cache-Control': 'no-cache'
      });

      const fileStream = fs.createReadStream(archivePath);
      fileStream.pipe(res);
    });
    return;
  }

  let filePath = '';
  let contentType = 'text/html';

  if (req.url === '/' || req.url === '/index.html') {
    filePath = path.join(__dirname, 'docs', 'index.html');
  } else if (req.url === '/styles.css') {
    filePath = path.join(__dirname, 'docs', 'styles.css');
    contentType = 'text/css';
  } else if (req.url.startsWith('/extension/')) {
    filePath = path.join(__dirname, req.url);
    if (req.url.endsWith('.json')) {
      contentType = 'application/json';
    } else if (req.url.endsWith('.js')) {
      contentType = 'application/javascript';
    } else if (req.url.endsWith('.png')) {
      contentType = 'image/png';
    }
  } else {
    filePath = path.join(__dirname, 'docs', 'index.html');
  }

  fs.readFile(filePath, (err, content) => {
    if (err) {
      res.writeHead(404, { 'Content-Type': 'text/html' });
      res.end('<h1>404 - Not Found</h1>', 'utf-8');
      return;
    }

    res.writeHead(200, { 
      'Content-Type': contentType,
      'Cache-Control': 'no-cache, no-store, must-revalidate'
    });
    res.end(content, 'utf-8');
  });
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`AdBlock Pro Documentation Server running on http://0.0.0.0:${PORT}`);
  console.log(`Ready to serve extension documentation and files`);
});
